import React from 'react'
import StatisticsPanel from '../../Components/StatisticsPanel'

const Statistics = () => {
  return (
    <StatisticsPanel/>
  )
}

export default Statistics